# Architecture (minMain)

- **App type:** Single-page HTML5 canvas game (`index.html` + `game.js`); no build step.
- **Config:** `config.js` defines `window.API_URL` (leave empty for offline/localStorage).
- **Offline:** `download.js` prefers `beyond-bell-offline.zip`, falls back to JSZip using the `textFiles`/`binaryFiles` lists. `sw.js` caches the same core assets for hosted/offline revisits.
- **Assets:** `music/` (main_theme.ogg, galactic_rap.ogg), `sfx/` (zap.wav), `jszip.min.js` for client ZIP fallback.
- **Serve locally:** Open `index.html` directly or run a simple static server (e.g., `start_server.ps1` in full project; any static server works here).
- **Update flow:** When adding files, update `download.js` lists, align `sw.js` ASSETS, then rebuild `beyond-bell-offline.zip` (run `package_offline.ps1`) so downloads mirror this folder.

