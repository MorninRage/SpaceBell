// API endpoint configuration; keep empty for offline/local play.
window.API_URL = window.API_URL || "";

